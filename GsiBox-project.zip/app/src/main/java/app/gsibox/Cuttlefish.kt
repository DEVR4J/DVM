package app.gsibox

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

/**
 * Turns an AOSP Cuttlefish image zip (aosp_cf_arm64_*-img-*.zip) into what QEMU needs:
 * kernel.img, ramdisk.img (vendor + generic ramdisk + bootconfig) and disk.img (GPT with named partitions).
 */
object Cuttlefish {
    private val WANT = setOf(
        "boot.img", "init_boot.img", "vendor_boot.img", "super.img",
        "vbmeta.img", "vbmeta_system.img", "vbmeta_vendor_dlkm.img", "vbmeta_system_dlkm.img"
    )

    /** PCI slot of the virtio disk; must match androidboot.boot_devices below. */
    const val DISK_SLOT = "0x7"
    private const val BOOT_DEVICE = "pci0000:00/0000:00:07.0"

    private fun copyStream(inp: InputStream, out: File) {
        out.outputStream().buffered(1 shl 20).use { o ->
            val buf = ByteArray(1 shl 20)
            while (true) {
                val n = inp.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
            }
        }
    }

    private fun fileWriter(f: File): (RandomAccessFile, Long) -> Unit = { raf, off ->
        raf.seek(off)
        f.inputStream().buffered(1 shl 20).use { i ->
            val buf = ByteArray(1 shl 20)
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                raf.write(buf, 0, n)
            }
        }
    }

    fun import(ctx: Context, uri: Uri, progress: (String) -> Unit): File {
        val dir = ctx.vmDir()
        val work = File(dir, "cf-work")
        work.deleteRecursively()
        work.mkdirs()

        val found = HashSet<String>()
        val raw = ctx.contentResolver.openInputStream(uri) ?: error("Cannot open the selected file.")
        raw.use { base ->
            val zin = ZipInputStream(BufferedInputStream(base, 1 shl 20))
            while (true) {
                val e = zin.nextEntry ?: break
                val n = e.name.substringAfterLast('/')
                if (e.isDirectory || n !in WANT) continue
                progress("reading $n ...")
                copyStream(zin, File(work, n))
                found.add(n)
            }
        }
        for (need in listOf("boot.img", "init_boot.img", "vendor_boot.img", "super.img")) {
            if (need !in found) {
                work.deleteRecursively()
                error("$need was not found in the zip. Use the Cuttlefish image zip (aosp_cf_arm64_..._img_....zip).")
            }
        }

        progress("extracting kernel ...")
        val kernel = File(dir, "kernel.img")
        val bootRd = File(work, "boot.rd")
        BootImg.extract(File(work, "boot.img"), kernel, bootRd)
        val kernelMsg = Kernel.normalize(kernel)
        val bootCmd = BootImg.cmdline(File(work, "boot.img"))

        progress("building ramdisk ...")
        val genRd = File(work, "init.rd")
        BootImg.ramdiskOnly(File(work, "init_boot.img"), genRd)
        val vendRd = File(work, "vendor.rd")
        val vb = VendorBoot.extract(File(work, "vendor_boot.img"), vendRd)

        val cfg = VmConfig(ctx)
        val existing = vb.bootconfig
        val haveKeys = HashSet<String>()
        for (line in existing.split('\n', ';')) {
            val k = line.trim().substringBefore('=').substringBefore(':').substringBefore('+').trim()
            if (k.isNotEmpty()) haveKeys.add(k)
        }
        val extra = linkedMapOf(
            "androidboot.hardware" to "cutf_cvm",
            "androidboot.boot_devices" to BOOT_DEVICE,
            "androidboot.slot_suffix" to "_a",
            "androidboot.force_normal_boot" to "1",
            "androidboot.verifiedbootstate" to "orange",
            "androidboot.vbmeta.device_state" to "unlocked",
            "androidboot.selinux" to "permissive",
            "androidboot.serialno" to "GSIBOX0001",
            "androidboot.hardware.gralloc" to "minigbm",
            "androidboot.hardware.hwcomposer" to "ranchu",
            "androidboot.hardware.hwcomposer.mode" to "client",
            "androidboot.hardware.hwcomposer.display_finder_mode" to "drm",
            "androidboot.hardware.egl" to "angle",
            "androidboot.hardware.vulkan" to "pastel",
            "androidboot.opengles.version" to "196609",
            "androidboot.lcd_density" to cfg.dpi.toString()
        )
        val bc = StringBuilder(existing.trim())
        for ((k, v) in extra) {
            if (k !in haveKeys) {
                if (bc.isNotEmpty()) bc.append('\n')
                bc.append(k).append(" = \"").append(v).append('"')
            }
        }
        bc.append('\n')

        // ramdisk.img = vendor ramdisk + (boot ramdisk) + generic ramdisk, padded, then bootconfig trailer
        val rd = File(dir, "ramdisk.img")
        rd.outputStream().buffered(1 shl 20).use { o ->
            var written = 0L
            for (f in listOf(vendRd, bootRd, genRd)) {
                if (!f.exists()) continue
                f.inputStream().buffered(1 shl 20).use { i ->
                    val buf = ByteArray(1 shl 20)
                    while (true) {
                        val n = i.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        written += n
                    }
                }
            }
            while (written % 4L != 0L) {
                o.write(0)
                written++
            }
            val data = bc.toString().toByteArray(Charsets.ISO_8859_1).toMutableList()
            data.add(0) // terminating NUL
            while (data.size % 4 != 0) data.add(0)
            val bytes = data.toByteArray()
            var sum = 0L
            for (x in bytes) sum += (x.toInt() and 0xff).toLong()
            o.write(bytes)
            val tail = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
            tail.putInt(bytes.size)
            tail.putInt((sum and 0xffffffffL).toInt())
            o.write(tail.array())
            o.write("#BOOTCONFIG\n".toByteArray(Charsets.US_ASCII))
        }

        // kernel command line: images' own first, ours last so our console wins
        val cmdline = listOf(
            bootCmd, vb.cmdline,
            "console=ttyAMA0 earlycon=pl011,mmio32,0x9000000 keep_bootcon loglevel=8 printk.devkmsg=on bootconfig"
        ).filter { it.isNotBlank() }.joinToString(" ") { it.trim() }
        File(dir, "cf.cmdline").writeText(cmdline)

        progress("building virtual disk (this takes a while) ...")
        val superFile = File(work, "super.img")
        val superSize = Sparse.rawSize(superFile)
        val parts = ArrayList<Part>()
        parts.add(Part("misc", 1L shl 20))
        for (n in listOf("vbmeta", "vbmeta_system", "vbmeta_vendor_dlkm", "vbmeta_system_dlkm")) {
            val f = File(work, "$n.img")
            if (f.exists()) parts.add(Part(n + "_a", f.length(), fileWriter(f)))
        }
        parts.add(
            Part("super", superSize) { raf, off ->
                if (Sparse.isSparse(superFile)) Sparse.unsparseInto(superFile, raf, off) else fileWriter(superFile)(raf, off)
            }
        )
        val metaSize = 16L shl 20
        parts.add(
            Part("metadata", metaSize) { raf, off ->
                raf.seek(off)
                GZIPInputStream(ctx.assets.open("metadata.img.gz")).use { gz ->
                    val buf = ByteArray(1 shl 16)
                    while (true) {
                        val n = gz.read(buf)
                        if (n < 0) break
                        raf.write(buf, 0, n)
                    }
                }
            }
        )
        parts.add(Part("userdata", cfg.dataGb.toLong() shl 30))
        val disk = File(dir, "disk.img")
        Gpt.build(disk, parts)

        work.deleteRecursively()
        progress("$kernelMsg Disk ready (${disk.length() shr 20} MB).")
        return disk
    }
}
