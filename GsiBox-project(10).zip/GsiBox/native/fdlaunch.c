/*
 * fdlaunch <dir> <program> [args...]
 * Opens the named pipes in <dir> on the fixed file descriptors that Cuttlefish's secure_env expects,
 * creates the listening socket for its confirmation-UI channel, then execs <program>.
 * An Android app cannot hand file descriptors to a child process, so this tiny static helper does it.
 *
 *   10/11 keymint     (10 = requests from guest, 11 = replies to guest)
 *   12/13 keymaster
 *   14/15 gatekeeper
 *   16/17 oemlock
 *   18    kernel events (never written to)
 *   19    listening unix socket  <dir>/confui.sock
 */
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <unistd.h>

static void put(int f, int fd) {
    if (f != fd) {
        if (dup2(f, fd) < 0) { perror("dup2"); exit(2); }
        close(f);
    }
}

static void fifo(const char *dir, const char *name, const char *sfx, int fd) {
    char p[600];
    snprintf(p, sizeof p, "%s/%s.%s", dir, name, sfx);
    if (mkfifo(p, 0600) < 0 && errno != EEXIST) { perror(p); exit(2); }
    int f = open(p, O_RDWR);
    if (f < 0) { perror(p); exit(2); }
    put(f, fd);
}

int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage: fdlaunch dir program [args]\n"); return 1; }
    const char *dir = argv[1];
    fifo(dir, "keymint", "out", 10);
    fifo(dir, "keymint", "in", 11);
    fifo(dir, "keymaster", "out", 12);
    fifo(dir, "keymaster", "in", 13);
    fifo(dir, "gatekeeper", "out", 14);
    fifo(dir, "gatekeeper", "in", 15);
    fifo(dir, "oemlock", "out", 16);
    fifo(dir, "oemlock", "in", 17);
    fifo(dir, "kernel_events", "out", 18);

    char sp[600];
    snprintf(sp, sizeof sp, "%s/confui.sock", dir);
    unlink(sp);
    int s = socket(AF_UNIX, SOCK_STREAM, 0);
    if (s < 0) { perror("socket"); return 2; }
    struct sockaddr_un a;
    memset(&a, 0, sizeof a);
    a.sun_family = AF_UNIX;
    strncpy(a.sun_path, sp, sizeof a.sun_path - 1);
    if (bind(s, (struct sockaddr *)&a, sizeof a) < 0) { perror("bind"); return 2; }
    if (listen(s, 4) < 0) { perror("listen"); return 2; }
    put(s, 19);

    execv(argv[2], &argv[2]);
    perror("execv");
    return 3;
}
