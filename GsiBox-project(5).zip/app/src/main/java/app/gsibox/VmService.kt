package app.gsibox

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import java.io.File

/** Runs the bundled QEMU binary (libqemu.so in nativeLibraryDir) as a child process. */
class VmService : Service() {

    companion object {
        @Volatile
        var process: Process? = null

        fun isRunning(): Boolean = process?.isAlive == true
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("vm", "Virtual Android", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "vm")
            .setContentTitle("GsiBox")
            .setContentText("Virtual Android is running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }

        if (intent?.action == "stop") {
            process?.destroyForcibly()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!isRunning()) startVm()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        process?.destroyForcibly()
        process = null
        super.onDestroy()
    }

    private fun buildArgs(qemu: String, c: VmConfig, dir: File): List<String> {
        // Use hardware virtualization when the device lets apps open /dev/kvm (rare), else software emulation.
        val kvm = File("/dev/kvm").let { it.canRead() && it.canWrite() }
        val a = mutableListOf(
            qemu,
            "-L", File(dir, "qemu-data").path,
            "-machine", if (kvm) "virt,gic-version=host" else "virt,gic-version=3",
            "-cpu", if (kvm) "host" else "max,pauth-impdef=on",
            "-accel", if (kvm) "kvm" else "tcg,thread=multi,tb-size=1024",
            "-smp", c.cpus.toString(),
            "-m", c.ramMb.toString(),
            "-kernel", File(dir, "kernel.img").path
        )
        val rd = File(dir, "ramdisk.img")
        if (rd.exists()) a += listOf("-initrd", rd.path)
        // GKI kernels build the PL011 serial driver as a module, so the kernel falls back to a null console.
        // keep_bootcon keeps the early console (earlycon) alive so the whole boot stays visible.
        var cl = c.cmdline
        if ("keep_bootcon" !in cl) cl += " keep_bootcon"
        if ("loglevel=" !in cl) cl += " loglevel=8"
        a += listOf("-append", "$cl androidboot.lcd_density=${c.dpi}")

        a += listOf(
            "-display", "none",
            "-vnc", "127.0.0.1:0",
            "-device", "virtio-gpu-pci,xres=${c.width},yres=${c.height}",
            "-device", "qemu-xhci",
            "-device", "usb-kbd",
            "-device", "usb-tablet",
            "-device", "virtio-rng-pci",
            "-netdev", "user,id=n0",
            "-device", "virtio-net-pci,netdev=n0,romfile=",
            "-serial", "file:" + File(dir, "console.log").path,
            "-monitor", "none",
            "-d", "guest_errors,unimp",
            "-D", File(dir, "qemu-debug.log").path
        )

        fun drive(id: String, f: File, ro: Boolean) = listOf(
            "-drive", "file=${f.path},if=none,id=$id,format=raw" + if (ro) ",readonly=on" else "",
            "-device", "virtio-blk-pci,drive=$id"
        )
        // Guest sees: system = vda, vendor = vdb (if present), userdata = next one.
        a += drive("sys", File(dir, "system.img"), true)
        val vendor = File(dir, "vendor.img")
        if (vendor.exists()) a += drive("ven", vendor, true)
        a += drive("data", File(dir, "userdata.img"), false)

        if (c.extraArgs.isNotBlank()) a += c.extraArgs.trim().split(Regex("\\s+"))
        return a
    }

    /** QEMU's VNC server needs keymap files; they ship inside the APK assets. */
    private fun ensureData(dir: File) {
        val km = File(dir, "qemu-data/keymaps")
        if (File(km, "en-us").exists()) return
        km.mkdirs()
        assets.list("qemu-data/keymaps")?.forEach { n ->
            assets.open("qemu-data/keymaps/$n").use { i ->
                File(km, n).outputStream().use { o -> i.copyTo(o) }
            }
        }
    }

    private fun startVm() {
        val dir = vmDir()
        try {
            ensureData(dir)
        } catch (e: Exception) {
            File(dir, "qemu.log").writeText("[could not extract keymaps: ${e.message}]\n")
        }
        val cfg = VmConfig(this)
        val qemu = File(applicationInfo.nativeLibraryDir, "libqemu.so")
        val log = File(dir, "qemu.log")
        File(dir, "console.log").delete()
        val args = buildArgs(qemu.path, cfg, dir)
        log.writeText("$ " + args.joinToString(" ") + "\n")

        Thread {
            try {
                val kf = File(dir, "kernel.img")
                log.appendText("[kernel] " + (try { Kernel.normalize(kf) } catch (e: Exception) { "check failed: ${e.message}" }) + "\n")
                log.appendText("[kernel info] " + Kernel.report(kf) + "\n")
                val p = ProcessBuilder(args)
                    .directory(dir)
                    .redirectErrorStream(true)
                    .redirectOutput(ProcessBuilder.Redirect.appendTo(log))
                    .start()
                process = p
                val code = p.waitFor()
                log.appendText("\n[qemu exited with code $code]\n")
            } catch (e: Exception) {
                log.appendText("\n[failed to start qemu: ${e.message}]\n")
            }
            process = null
            stopSelf()
        }.start()
    }
}
