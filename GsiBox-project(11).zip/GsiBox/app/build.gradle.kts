plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.gsibox"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.gsibox"
        minSdk = 26
        // 28 lets the app run programs it unpacked itself (needed for the KeyMint helper)
        targetSdk = 28
        versionCode = 1
        versionName = "0.1"
        ndk { abiFilters += "arm64-v8a" }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // libqemu.so is really an executable. It must be extracted to
    // nativeLibraryDir at install time so the app is allowed to exec it.
    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    implementation("org.tukaani:xz:1.9")
}
