package app.gsibox

import android.content.Context
import android.net.Uri
import android.system.Os
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.util.zip.GZIPInputStream

/**
 * The Cuttlefish image needs a KeyMint/gatekeeper "host" program (secure_env) that normally runs next to the VM.
 * It ships in cvd-host_package.tar.gz (aarch64 build). This unpacks just what it needs and runs it,
 * connected to the VM through named pipes (QEMU virtio serial ports -> /dev/hvcN in the guest).
 */
object CvdHost {
    fun root(ctx: Context) = File(ctx.vmDir(), "cvdhost")
    fun secureEnv(ctx: Context) = File(root(ctx), "bin/secure_env")
    private fun launcher(ctx: Context) = File(ctx.applicationInfo.nativeLibraryDir, "libfdlaunch.so")
    fun runDir(ctx: Context) = File(ctx.vmDir(), "cvd-run")
    fun ready(ctx: Context) = secureEnv(ctx).exists() && launcher(ctx).exists()

    @Volatile
    var helper: Process? = null

    fun stop() {
        helper?.destroyForcibly()
        helper = null
    }

    // ---------- import (tar.gz reader) ----------

    private fun readFully(i: InputStream, b: ByteArray): Boolean {
        var n = 0
        while (n < b.size) {
            val r = i.read(b, n, b.size - n)
            if (r < 0) return n > 0 && false
            n += r
        }
        return true
    }

    private fun skipN(i: InputStream, n: Long) {
        var left = n
        val buf = ByteArray(64 shl 10)
        while (left > 0) {
            val r = i.read(buf, 0, minOf(left, buf.size.toLong()).toInt())
            if (r < 0) break
            left -= r
        }
    }

    private fun cstr(b: ByteArray, off: Int, len: Int): String {
        var e = off
        while (e < off + len && b[e] != 0.toByte()) e++
        return String(b, off, e - off, Charsets.UTF_8)
    }

    private fun num(b: ByteArray, off: Int, len: Int): Long {
        if ((b[off].toInt() and 0x80) != 0) {
            var v = (b[off].toInt() and 0x7f).toLong()
            for (k in 1 until len) v = (v shl 8) or (b[off + k].toLong() and 0xff)
            return v
        }
        var v = 0L
        for (k in off until off + len) {
            val c = b[k].toInt().toChar()
            if (c in '0'..'7') v = v * 8 + (c - '0') else if (v > 0 || c == ' ' && false) break
        }
        return v
    }

    private fun wanted(n: String) = n == "bin/secure_env" || n.startsWith("lib64/")

    fun import(ctx: Context, uri: Uri, progress: (String) -> Unit): File {
        val dir = ctx.vmDir()
        val tmp = File(dir, "cvdhost.tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        val raw = ctx.contentResolver.openInputStream(uri) ?: error("Cannot open the selected file.")
        var kept = 0
        raw.use { base ->
            var inp: InputStream = BufferedInputStream(base, 1 shl 20)
            inp.mark(4)
            val m0 = inp.read()
            val m1 = inp.read()
            inp.reset()
            if (m0 == 0x1f && m1 == 0x8b) inp = BufferedInputStream(GZIPInputStream(inp, 1 shl 16), 1 shl 20)
            val hdr = ByteArray(512)
            var longName: String? = null
            while (true) {
                if (!readFully(inp, hdr)) break
                if (hdr.all { it == 0.toByte() }) break
                var name = cstr(hdr, 0, 100)
                if (cstr(hdr, 257, 5) == "ustar") {
                    val pre = cstr(hdr, 345, 155)
                    if (pre.isNotEmpty()) name = "$pre/$name"
                }
                val size = num(hdr, 124, 12)
                val type = hdr[156].toInt().toChar()
                val link = cstr(hdr, 157, 100)
                val pad = (512 - size % 512) % 512
                when (type) {
                    'L' -> {
                        val b = ByteArray(size.toInt())
                        readFully(inp, b)
                        skipN(inp, pad)
                        longName = String(b, Charsets.UTF_8).trimEnd('\u0000')
                        continue
                    }
                    'x' -> {
                        val b = ByteArray(size.toInt())
                        readFully(inp, b)
                        skipN(inp, pad)
                        for (line in String(b, Charsets.UTF_8).split('\n')) {
                            val kv = line.substringAfter(' ', "")
                            if (kv.startsWith("path=")) longName = kv.removePrefix("path=")
                        }
                        continue
                    }
                    'g' -> {
                        skipN(inp, size + pad)
                        continue
                    }
                }
                if (longName != null) {
                    name = longName!!
                    longName = null
                }
                name = name.removePrefix("./").trimEnd('/')
                val dest = File(tmp, name)
                val keep = wanted(name)
                when {
                    keep && (type == '0' || type == '\u0000') -> {
                        dest.parentFile?.mkdirs()
                        dest.outputStream().buffered(1 shl 20).use { o ->
                            var left = size
                            val buf = ByteArray(1 shl 20)
                            while (left > 0) {
                                val r = inp.read(buf, 0, minOf(left, buf.size.toLong()).toInt())
                                if (r < 0) break
                                o.write(buf, 0, r)
                                left -= r
                            }
                        }
                        skipN(inp, pad)
                        kept++
                        if (kept % 10 == 0) progress("unpacked $kept files ...")
                    }
                    keep && type == '2' -> {
                        dest.parentFile?.mkdirs()
                        try {
                            Os.symlink(link, dest.path)
                        } catch (e: Exception) {
                        }
                        skipN(inp, size + pad)
                    }
                    keep && type == '1' -> {
                        dest.parentFile?.mkdirs()
                        val src = File(tmp, link.removePrefix("./"))
                        if (src.exists()) src.copyTo(dest, overwrite = true)
                        skipN(inp, size + pad)
                    }
                    else -> skipN(inp, size + pad)
                }
            }
        }
        val se = File(tmp, "bin/secure_env")
        if (!se.exists()) {
            tmp.deleteRecursively()
            error("bin/secure_env was not found in this file. Use cvd-host_package.tar.gz from the arm64 Cuttlefish build.")
        }
        val machine = se.inputStream().use { i ->
            val h = ByteArray(20)
            i.read(h)
            (h[18].toInt() and 0xff) or ((h[19].toInt() and 0xff) shl 8)
        }
        if (machine != 183) {
            tmp.deleteRecursively()
            error("This package is not for arm64 (ELF machine $machine). Download the aarch64 cvd-host_package.tar.gz.")
        }
        se.setExecutable(true, false)
        val dst = root(ctx)
        dst.deleteRecursively()
        if (!tmp.renameTo(dst)) error("Could not store the helper files.")
        return secureEnv(ctx)
    }

    // ---------- running ----------

    /** hvc index in the guest -> channel name. Cuttlefish numbering: keymaster 3, gatekeeper 4, oemlock 10, keymint 11. */
    private val hvc = mapOf(3 to "keymaster", 4 to "gatekeeper", 10 to "oemlock", 11 to "keymint")
    private const val HVC_COUNT = 14

    /** Starts secure_env through libfdlaunch.so. Returns a note for the log. */
    fun start(ctx: Context): String {
        stop()
        val se = secureEnv(ctx)
        val run = runDir(ctx)
        run.deleteRecursively()
        run.mkdirs()
        val root = File(run, "cuttlefish")
        val inst = File(root, "instances/cvd-1")
        for (d in listOf("logs", "internal", "assembly")) File(inst, d).mkdirs()
        File(root, "assembly").mkdirs()
        val cfg = File(run, "cf.json")
        cfg.writeText("{\"root_dir\":\"${root.path}\",\"instances\":{\"1\":{\"instance_dir\":\"${inst.path}\"}}}")
        // fifos are made here so QEMU and the helper can both open them
        for (n in listOf("keymint", "keymaster", "gatekeeper", "oemlock")) {
            for (s in listOf("in", "out")) {
                val f = File(run, "$n.$s")
                if (!f.exists()) Os.mkfifo(f.path, 384)
            }
        }
        val cmd = mutableListOf(
            launcher(ctx).path, run.path, se.path,
            "--keymint_impl=software", "--gatekeeper_impl=software", "--oemlock_impl=software",
            "--keymint_fd_in=10", "--keymint_fd_out=11",
            "--keymaster_fd_in=12", "--keymaster_fd_out=13",
            "--gatekeeper_fd_in=14", "--gatekeeper_fd_out=15",
            "--oemlock_fd_in=16", "--oemlock_fd_out=17",
            "--kernel_events_fd=18", "--confui_server_fd=19"
        )
        val pb = ProcessBuilder(cmd).directory(run).redirectErrorStream(true)
            .redirectOutput(File(ctx.vmDir(), "secure_env.log"))
        pb.environment()["CUTTLEFISH_CONFIG_FILE"] = cfg.path
        pb.environment()["HOME"] = run.path
        val p = pb.start()
        helper = p
        Thread.sleep(1500)
        return if (p.isAlive) "[keymint helper started]" else "[keymint helper exited at once with code ${p.exitValue()} - see secure_env log]"
    }

    /** QEMU arguments: 14 virtio-serial consoles so the guest gets /dev/hvc0../dev/hvc13 in Cuttlefish order. */
    fun qemuArgs(ctx: Context): List<String> {
        val run = runDir(ctx)
        val a = ArrayList<String>()
        for (i in 0 until HVC_COUNT) {
            val name = hvc[i]
            a += listOf("-chardev", if (name != null) "pipe,id=hv$i,path=${File(run, name).path}" else "null,id=hv$i")
            a += listOf("-device", "virtio-serial-pci,id=vs$i,max_ports=1,addr=0x${(0x10 + i).toString(16)}")
            a += listOf("-device", "virtconsole,chardev=hv$i,bus=vs$i.0")
        }
        return a
    }
}
