package app.gsibox

import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.GZIPInputStream

/** Lists file names inside Android ramdisks (lz4-legacy / gzip / raw "newc" cpio, possibly concatenated). */
object Cpio {
    private const val LZ4_MAGIC = 0x184C2102

    private fun le32(b: ByteArray, p: Int) =
        (b[p].toInt() and 0xff) or ((b[p + 1].toInt() and 0xff) shl 8) or
            ((b[p + 2].toInt() and 0xff) shl 16) or ((b[p + 3].toInt() and 0xff) shl 24)

    private fun isLz4(b: ByteArray, p: Int) = p + 8 <= b.size && le32(b, p) == LZ4_MAGIC

    private fun isGzip(b: ByteArray, p: Int) = p + 2 <= b.size && b[p] == 0x1f.toByte() && b[p + 1] == 0x8b.toByte()

    /** Decodes consecutive lz4-legacy frames starting at [start]; returns data and the end offset. */
    private fun lz4Frames(src: ByteArray, start: Int): Pair<ByteArray, Int> {
        val out = ByteArrayOutputStream()
        val dst = ByteArray(8 shl 20)
        var p = start
        while (p + 4 <= src.size) {
            val size = le32(src, p)
            if (size == LZ4_MAGIC) {
                p += 4
                continue
            }
            if (size <= 0 || p + 4 + size > src.size) break
            val n = Kernel.lz4Block(src, p + 4, p + 4 + size, dst)
            out.write(dst, 0, n)
            p += 4 + size
        }
        return Pair(out.toByteArray(), p)
    }

    fun names(f: File): List<String> {
        val data = f.readBytes()
        val names = ArrayList<String>()
        var p = 0
        try {
            while (p < data.size) {
                if (isLz4(data, p)) {
                    val (raw, next) = lz4Frames(data, p)
                    scan(raw, names)
                    if (next <= p) break
                    p = next
                } else if (isGzip(data, p)) {
                    val raw = GZIPInputStream(data.inputStream(p, data.size - p)).use { it.readBytes() }
                    scan(raw, names)
                    break // compressed length unknown
                } else {
                    scan(data.copyOfRange(p, data.size), names)
                    break
                }
            }
        } catch (e: Exception) {
            names.add("(scan stopped: ${e.message})")
        }
        return names
    }

    private fun scan(d: ByteArray, out: MutableList<String>) {
        var p = 0
        while (p + 110 <= d.size) {
            if (String(d, p, 6, Charsets.ISO_8859_1) != "070701" && String(d, p, 6, Charsets.ISO_8859_1) != "070702") {
                p += 4
                continue
            }
            val fsz = String(d, p + 54, 8, Charsets.ISO_8859_1).toLong(16)
            val nsz = String(d, p + 94, 8, Charsets.ISO_8859_1).toLong(16)
            if (nsz < 1 || p + 110 + nsz > d.size) break
            val name = String(d, p + 110, (nsz - 1).toInt(), Charsets.ISO_8859_1)
            out.add(name)
            var q = p + 110 + nsz.toInt()
            q = (q + 3) and 3.inv()
            q += fsz.toInt()
            q = (q + 3) and 3.inv()
            p = q
        }
    }

    /** Suffixes of every /fstab.<suffix> file found, e.g. "cf.f2fs.hctr2". */
    fun fstabSuffixes(f: File): List<String> =
        names(f).map { it.substringAfterLast('/') }
            .filter { it.startsWith("fstab.") }
            .map { it.removePrefix("fstab.") }
            .distinct()
}
