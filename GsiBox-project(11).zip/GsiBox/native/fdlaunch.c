/*
 * fdlaunch <dir> <program> [args...]
 * Opens the named pipes in <dir> (made beforehand by the app) on the fixed file descriptors that
 * Cuttlefish's secure_env expects, creates the listening socket for its confirmation-UI channel,
 * then execs <program>. An Android app cannot hand file descriptors to a child process, so this
 * tiny helper does it.
 *
 * It uses raw system calls and no C library: Android's app sandbox (seccomp) kills programs that
 * make calls outside its allow-list, and a normal glibc start-up does.
 *
 *   10/11 keymint     (10 = requests from guest, 11 = replies to guest)
 *   12/13 keymaster
 *   14/15 gatekeeper
 *   16/17 oemlock
 *   18    kernel events (never written to)
 *   19    listening unix socket  <dir>/confui.sock
 */
#include <sys/syscall.h>

typedef long L;

static inline L sys(L n, L a, L b, L c, L d) {
#if defined(__aarch64__)
    register L x8 __asm__("x8") = n;
    register L x0 __asm__("x0") = a;
    register L x1 __asm__("x1") = b;
    register L x2 __asm__("x2") = c;
    register L x3 __asm__("x3") = d;
    __asm__ volatile("svc 0" : "+r"(x0) : "r"(x8), "r"(x1), "r"(x2), "r"(x3) : "memory", "cc");
    return x0;
#elif defined(__x86_64__)
    L r;
    register L r10 __asm__("r10") = d;
    __asm__ volatile("syscall" : "=a"(r) : "0"(n), "D"(a), "S"(b), "d"(c), "r"(r10) : "rcx", "r11", "memory");
    return r;
#else
#error unsupported architecture
#endif
}

static L slen(const char *s) { L n = 0; while (s[n]) n++; return n; }

static void die(const char *a, const char *b) {
    sys(SYS_write, 2, (L)a, slen(a), 0);
    if (b) { sys(SYS_write, 2, (L)b, slen(b), 0); }
    sys(SYS_write, 2, (L)"\n", 1, 0);
    sys(SYS_exit, 2, 0, 0, 0);
    for (;;) {}
}

static char *cat(char *d, const char *s) { while (*s) *d++ = *s++; return d; }

static void put(L f, L fd) {
    if (f != fd) {
        if (sys(SYS_dup3, f, fd, 0, 0) < 0) die("dup3 failed", 0);
        sys(SYS_close, f, 0, 0, 0);
    }
}

static void fifo(const char *dir, const char *name, const char *sfx, L fd) {
    char p[400];
    char *e = cat(p, dir);
    e = cat(e, "/");
    e = cat(e, name);
    e = cat(e, ".");
    e = cat(e, sfx);
    *e = 0;
    L f = sys(SYS_openat, -100, (L)p, 2 /* O_RDWR */, 0);
    if (f < 0) die("cannot open ", p);
    put(f, fd);
}

__attribute__((noreturn, used)) void cmain(L *sp) {
    L argc = sp[0];
    char **argv = (char **)(sp + 1);
    char **envp = argv + argc + 1;
    if (argc < 3) die("usage: fdlaunch dir program [args]", 0);
    const char *dir = argv[1];

    fifo(dir, "keymint", "out", 10);
    fifo(dir, "keymint", "in", 11);
    fifo(dir, "keymaster", "out", 12);
    fifo(dir, "keymaster", "in", 13);
    fifo(dir, "gatekeeper", "out", 14);
    fifo(dir, "gatekeeper", "in", 15);
    fifo(dir, "oemlock", "out", 16);
    fifo(dir, "oemlock", "in", 17);
    fifo(dir, "kernel_events", "out", 18);

    char sp_[200];
    char *e = cat(sp_, dir);
    e = cat(e, "/confui.sock");
    *e = 0;
    if (slen(sp_) > 100) die("socket path too long", 0);
    sys(SYS_unlinkat, -100, (L)sp_, 0, 0);
    L s = sys(SYS_socket, 1 /* AF_UNIX */, 1 /* SOCK_STREAM */, 0, 0);
    if (s < 0) die("socket failed", 0);
    char addr[110];
    for (int i = 0; i < 110; i++) addr[i] = 0;
    addr[0] = 1; /* sun_family = AF_UNIX (little endian u16) */
    for (L i = 0; sp_[i]; i++) addr[2 + i] = sp_[i];
    if (sys(SYS_bind, s, (L)addr, 110, 0) < 0) die("bind failed: ", sp_);
    if (sys(SYS_listen, s, 4, 0, 0) < 0) die("listen failed", 0);
    put(s, 19);

    sys(SYS_execve, (L)argv[2], (L)&argv[2], (L)envp, 0);
    die("execve failed: ", argv[2]);
    for (;;) {}
}

#if defined(__aarch64__)
__asm__(".global _start\n_start:\n mov x0, sp\n b cmain\n");
#elif defined(__x86_64__)
__asm__(".global _start\n_start:\n mov %rsp, %rdi\n and $-16, %rsp\n call cmain\n");
#endif
