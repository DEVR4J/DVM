package app.gsibox

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.RandomAccessFile

class MainActivity : Activity() {
    private lateinit var cfg: VmConfig
    private lateinit var status: TextView
    private lateinit var busy: ProgressBar
    private lateinit var startBtn: Button
    private lateinit var ramSp: Spinner
    private lateinit var cpuSp: Spinner
    private lateinit var dataSp: Spinner
    private lateinit var presetSp: Spinner
    private lateinit var wEt: EditText
    private lateinit var hEt: EditText
    private lateinit var dpiEt: EditText
    private lateinit var cmdEt: EditText
    private lateinit var extraEt: EditText
    private val rows = HashMap<String, TextView>()

    private val ui = Handler(Looper.getMainLooper())
    private var importing = false

    // request code -> (kind, button label)
    private val picks = listOf(
        Triple(1, "system", "GSI system image"),
        Triple(2, "boot", "boot.img (kernel + ramdisk)"),
        Triple(3, "kernel", "Kernel only (arm64 Image)"),
        Triple(4, "ramdisk", "Ramdisk only"),
        Triple(5, "vendor", "Vendor image")
    )

    private val presets = listOf(
        Triple("Phone 720 x 1280", 720 to 1280, 280),
        Triple("Phone 1080 x 2400", 1080 to 2400, 420),
        Triple("Tablet 1200 x 1920", 1200 to 1920, 240),
        Triple("Custom", 0 to 0, 0)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = VmConfig(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 56, 40, 56)
        }

        fun label(t: String, size: Float = 14f, color: Int = Color.DKGRAY) = TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            setPadding(0, 24, 0, 6)
        }.also { col.addView(it) }

        fun spin(vals: List<Any>, cur: Any) = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, vals)
            setSelection(vals.indexOf(cur).coerceAtLeast(0))
        }.also { col.addView(it) }

        fun edit(v: String, number: Boolean = false) = EditText(this).apply {
            setText(v)
            if (number) inputType = InputType.TYPE_CLASS_NUMBER
        }.also { col.addView(it) }

        label("GsiBox", 28f, Color.BLACK)
        label("Virtual Android, running inside this app.")

        label("Files", 18f, Color.BLACK)
        for ((code, kind, title) in picks) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val state = TextView(this).apply {
                textSize = 12f
                setPadding(16, 0, 0, 0)
            }
            rows[kind] = state
            row.addView(
                Button(this).apply {
                    text = title
                    isAllCaps = false
                    setOnClickListener { pick(code) }
                },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 3f)
            )
            row.addView(state, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f).apply { gravity = android.view.Gravity.CENTER_VERTICAL })
            col.addView(row)
        }
        busy = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = View.GONE
        }
        col.addView(busy)
        status = label("", 12f)

        label("Display", 18f, Color.BLACK)
        val presetNames = presets.map { it.first }
        val curPreset = presets.firstOrNull { it.second.first == cfg.width && it.second.second == cfg.height && it.third == cfg.dpi }?.first ?: "Custom"
        presetSp = spin(presetNames, curPreset)
        label("Width (px)")
        wEt = edit(cfg.width.toString(), true)
        label("Height (px)")
        hEt = edit(cfg.height.toString(), true)
        label("Density (dpi)")
        dpiEt = edit(cfg.dpi.toString(), true)
        presetSp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val p0 = presets[pos]
                if (p0.second.first > 0) {
                    wEt.setText(p0.second.first.toString())
                    hEt.setText(p0.second.second.toString())
                    dpiEt.setText(p0.third.toString())
                }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        label("Hardware", 18f, Color.BLACK)
        label("RAM (MB)")
        ramSp = spin(listOf(2048, 3072, 4096, 6144, 8192), cfg.ramMb)
        label("CPU cores")
        cpuSp = spin((1..8).toList(), cfg.cpus)
        label("Storage size (GB)")
        dataSp = spin(listOf(8, 16, 32, 64, 128), cfg.dataGb)

        label("Advanced", 18f, Color.BLACK)
        label("Kernel command line")
        cmdEt = edit(cfg.cmdline)
        label("Extra QEMU arguments")
        extraEt = edit(cfg.extraArgs)

        startBtn = Button(this).apply {
            isAllCaps = false
            textSize = 16f
            setOnClickListener { start() }
        }
        col.addView(startBtn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 40 })
        col.addView(Button(this).apply {
            text = "Erase VM storage"
            isAllCaps = false
            setOnClickListener { resetData() }
        })

        setContentView(ScrollView(this).apply { addView(col) })
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun ready(): Boolean {
        val d = vmDir()
        return File(d, "system.img").exists() && File(d, "kernel.img").exists()
    }

    private fun refresh() {
        val d = vmDir()
        for ((_, kind, _) in picks) {
            val f = File(d, if (kind == "boot") "kernel.img" else "$kind.img")
            val t = rows[kind] ?: continue
            if (kind == "boot") {
                t.text = ""
                continue
            }
            val has = f.exists()
            t.text = if (has) "✓ ${f.length() shr 20} MB" else if (kind == "system" || kind == "kernel") "required" else "optional"
            t.setTextColor(if (has) 0xFF2E7D32.toInt() else Color.GRAY)
        }
        startBtn.text = when {
            VmService.isRunning() -> "Open running VM"
            ready() -> "Start virtual Android"
            else -> "Add a GSI and kernel (or boot.img) first"
        }
        startBtn.isEnabled = !importing && (VmService.isRunning() || ready())
    }

    private fun pick(code: Int) {
        if (importing) return
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, code)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        val kind = picks.firstOrNull { it.first == requestCode }?.second
        if (resultCode != RESULT_OK || uri == null || kind == null) return
        importing = true
        busy.visibility = View.VISIBLE
        startBtn.isEnabled = false
        status.text = "Importing..."
        Thread {
            try {
                var last = ""
                Importer.importFile(this, uri, kind) { m ->
                    last = m
                    ui.post { status.text = m }
                }
                ui.post { status.text = "Done. $last" }
            } catch (e: Exception) {
                ui.post { status.text = "Import failed: ${e.message}" }
            }
            ui.post {
                importing = false
                busy.visibility = View.GONE
                refresh()
            }
        }.start()
    }

    private fun save() {
        cfg.ramMb = ramSp.selectedItem as Int
        cfg.cpus = cpuSp.selectedItem as Int
        cfg.dataGb = dataSp.selectedItem as Int
        cfg.width = wEt.text.toString().toIntOrNull()?.coerceIn(320, 2160) ?: 720
        cfg.height = hEt.text.toString().toIntOrNull()?.coerceIn(320, 3840) ?: 1280
        cfg.dpi = dpiEt.text.toString().toIntOrNull()?.coerceIn(120, 640) ?: 280
        cfg.cmdline = cmdEt.text.toString().trim()
        cfg.extraArgs = extraEt.text.toString().trim()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun start() {
        if (VmService.isRunning()) {
            startActivity(Intent(this, VmActivity::class.java))
            return
        }
        if (!File(applicationInfo.nativeLibraryDir, "libqemu.so").exists()) {
            toast("This build does not contain the QEMU binary. Check the CI build log.")
            return
        }
        save()
        val ud = File(vmDir(), "userdata.img")
        val want = cfg.dataGb.toLong() shl 30
        if (ud.exists() && ud.length() != want) {
            AlertDialog.Builder(this)
                .setTitle("Storage size changed")
                .setMessage("Recreate storage at ${cfg.dataGb} GB? This erases everything inside the VM.")
                .setPositiveButton("Recreate") { _, _ ->
                    ud.delete()
                    launch()
                }
                .setNegativeButton("Keep old size") { _, _ -> launch() }
                .show()
        } else {
            launch()
        }
    }

    private fun launch() {
        val ud = File(vmDir(), "userdata.img")
        if (!ud.exists()) {
            RandomAccessFile(ud, "rw").use { it.setLength(cfg.dataGb.toLong() shl 30) } // sparse
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        startForegroundService(Intent(this, VmService::class.java))
        startActivity(Intent(this, VmActivity::class.java))
    }

    private fun resetData() {
        if (VmService.isRunning()) {
            toast("Power off the VM first.")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Erase VM storage?")
            .setMessage("All apps and data inside the virtual Android will be deleted.")
            .setPositiveButton("Erase") { _, _ ->
                File(vmDir(), "userdata.img").delete()
                toast("Storage erased.")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
