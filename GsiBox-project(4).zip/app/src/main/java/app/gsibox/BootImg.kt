package app.gsibox

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Extracts kernel and ramdisk from an Android boot.img (header versions 0-4). */
object BootImg {
    class Result(val kernelSize: Long, val ramdiskSize: Long, val version: Int)

    private fun align(v: Long, a: Long) = (v + a - 1) / a * a

    fun isBootImg(f: File): Boolean = RandomAccessFile(f, "r").use {
        val m = ByteArray(8)
        it.length() > 4096 && it.read(m) == 8 && String(m) == "ANDROID!"
    }

    fun extract(src: File, kernelOut: File, ramdiskOut: File): Result {
        RandomAccessFile(src, "r").use { raf ->
            val h = ByteArray(48)
            raf.readFully(h)
            val b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
            val ver = b.getInt(40)
            val kSize: Long
            val rSize: Long
            val page: Long
            if (ver >= 3) {
                kSize = b.getInt(8).toLong() and 0xffffffffL
                rSize = b.getInt(12).toLong() and 0xffffffffL
                page = 4096
            } else {
                kSize = b.getInt(8).toLong() and 0xffffffffL
                rSize = b.getInt(16).toLong() and 0xffffffffL
                page = (b.getInt(36).toLong() and 0xffffffffL).coerceAtLeast(2048)
            }
            if (kSize == 0L) error("boot.img has no kernel (GKI boot images that are not v0-v4 are unsupported).")
            val kOff = page
            val rOff = kOff + align(kSize, page)
            copy(raf, kOff, kSize, kernelOut)
            if (rSize > 0) copy(raf, rOff, rSize, ramdiskOut) else ramdiskOut.delete()
            return Result(kSize, rSize, ver)
        }
    }

    private fun copy(raf: RandomAccessFile, off: Long, len: Long, out: File) {
        raf.seek(off)
        out.outputStream().buffered(1 shl 20).use { o ->
            val buf = ByteArray(1 shl 20)
            var left = len
            while (left > 0) {
                val n = raf.read(buf, 0, minOf(left, buf.size.toLong()).toInt())
                if (n < 0) error("boot.img is truncated.")
                o.write(buf, 0, n)
                left -= n
            }
        }
    }
}
