package app.gsibox

import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Converts Android sparse images (what most GSI system.img files are) to raw images QEMU can read. */
object Sparse {
    private const val MAGIC = -0x12d900c6 // 0xED26FF3A as a signed int

    fun isSparse(f: File): Boolean {
        FileInputStream(f).use {
            val b = ByteArray(4)
            if (it.read(b) != 4) return false
            return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).int == MAGIC
        }
    }

    private fun DataInputStream.skipFully(n: Long) {
        var left = n
        val tmp = ByteArray(8192)
        while (left > 0) {
            val r = read(tmp, 0, minOf(left, tmp.size.toLong()).toInt())
            if (r < 0) throw EOFException()
            left -= r
        }
    }

    fun unsparse(src: File, dst: File) {
        DataInputStream(BufferedInputStream(FileInputStream(src), 1 shl 20)).use { inp ->
            val h = ByteArray(28)
            inp.readFully(h)
            val hb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
            hb.int            // magic
            hb.short          // major
            hb.short          // minor
            val fileHdr = hb.short.toInt() and 0xffff
            val chunkHdr = hb.short.toInt() and 0xffff
            val blk = hb.int
            val totalBlks = hb.int
            val chunks = hb.int
            if (fileHdr > 28) inp.skipFully((fileHdr - 28).toLong())

            dst.delete()
            RandomAccessFile(dst, "rw").use { out ->
                var pos = 0L
                val buf = ByteArray(1 shl 20)
                repeat(chunks) {
                    val ch = ByteArray(12)
                    inp.readFully(ch)
                    val cb = ByteBuffer.wrap(ch).order(ByteOrder.LITTLE_ENDIAN)
                    val type = cb.short.toInt() and 0xffff
                    cb.short
                    val sz = cb.int.toLong() and 0xffffffffL
                    if (chunkHdr > 12) inp.skipFully((chunkHdr - 12).toLong())
                    val bytes = sz * blk
                    when (type) {
                        0xCAC1 -> { // raw
                            out.seek(pos)
                            var left = bytes
                            while (left > 0) {
                                val n = minOf(left, buf.size.toLong()).toInt()
                                inp.readFully(buf, 0, n)
                                out.write(buf, 0, n)
                                left -= n
                            }
                        }
                        0xCAC2 -> { // fill
                            val fill = ByteArray(4)
                            inp.readFully(fill)
                            if (fill.any { it.toInt() != 0 }) {
                                for (i in buf.indices) buf[i] = fill[i and 3]
                                out.seek(pos)
                                var left = bytes
                                while (left > 0) {
                                    val n = minOf(left, buf.size.toLong()).toInt()
                                    out.write(buf, 0, n)
                                    left -= n
                                }
                            }
                        }
                        0xCAC3 -> {} // don't care -> leave a hole
                        0xCAC4 -> inp.skipFully(4) // crc
                        else -> throw IllegalStateException("bad sparse chunk type $type")
                    }
                    pos += bytes
                }
                out.setLength(totalBlks.toLong() * blk)
            }
        }
    }
}
