package app.gsibox

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.io.RandomAccessFile

/** Shows the running virtual phone and provides navigation / typing helpers. */
class VmActivity : Activity() {
    private lateinit var view: VncView
    private lateinit var client: VncClient

    // X11 keysyms
    private val meta = 0xffeb
    private val alt = 0xffe9
    private val esc = 0xff1b
    private val enter = 0xff0d
    private val tab = 0xff09

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        view = VncView(this)
        client = VncClient(
            onChange = { view.postInvalidate() },
            onStatus = { s ->
                view.status = if (s.isEmpty()) "" else if (VmService.isRunning()) s else "VM is not running (see Log)"
                view.postInvalidate()
            }
        )
        view.client = client

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xFF202020.toInt())
        }
        fun add(t: String, f: () -> Unit) {
            bar.addView(
                Button(this).apply {
                    text = t
                    textSize = 11f
                    isAllCaps = false
                    setOnClickListener { f() }
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
        }
        add("Back") { client.combo(meta, esc) }
        add("Home") { client.combo(meta, enter) }
        add("Recents") { client.combo(alt, tab) }
        add("Type") { typeDialog() }
        add("Log") { logDialog() }
        add("Stop") { stopDialog() }

        info = TextView(this).apply {
            textSize = 10f
            setTextColor(0xFFB0B0B0.toInt())
            setBackgroundColor(0xFF101010.toInt())
            setPadding(16, 6, 16, 6)
            maxLines = 1
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(info, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        client.start()
        t0 = System.currentTimeMillis()
        tick.run()
    }

    private lateinit var info: TextView
    private var t0 = 0L
    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val s = (System.currentTimeMillis() - t0) / 1000
            val last = try {
                tail(File(vmDir(), "console.log"), 600).trim().lines().lastOrNull { it.isNotBlank() } ?: ""
            } catch (e: Exception) {
                ""
            }
            val state = if (VmService.isRunning()) "Running" else "Stopped"
            val hint = if (last.isEmpty() && s > 20 && VmService.isRunning())
                "No kernel output yet - kernel may be incompatible (see Log)" else last.take(120)
            info.text = "$state ${s / 60}:${"%02d".format(s % 60)}  $hint"
            ui.postDelayed(this, 1000)
        }
    }

    // Back button leaves the VM running in the background and returns to the setup screen.
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        finish()
    }

    override fun onDestroy() {
        ui.removeCallbacks(tick)
        client.stop() // the VM itself keeps running in the service
        super.onDestroy()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val sym: Int? = when (e.keyCode) {
            KeyEvent.KEYCODE_ENTER -> enter
            KeyEvent.KEYCODE_DEL -> 0xff08
            KeyEvent.KEYCODE_ESCAPE -> esc
            KeyEvent.KEYCODE_TAB -> tab
            KeyEvent.KEYCODE_DPAD_LEFT -> 0xff51
            KeyEvent.KEYCODE_DPAD_UP -> 0xff52
            KeyEvent.KEYCODE_DPAD_RIGHT -> 0xff53
            KeyEvent.KEYCODE_DPAD_DOWN -> 0xff54
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN -> null
            else -> e.unicodeChar.takeIf { it > 0 }
        }
        if (sym == null) return super.dispatchKeyEvent(e)
        when (e.action) {
            KeyEvent.ACTION_DOWN -> client.key(true, sym)
            KeyEvent.ACTION_UP -> client.key(false, sym)
        }
        return true
    }

    private fun typeDialog() {
        val et = EditText(this)
        AlertDialog.Builder(this)
            .setTitle("Type into the VM")
            .setView(et)
            .setPositiveButton("Send") { _, _ -> client.typeText(et.text.toString()) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun stopDialog() {
        AlertDialog.Builder(this)
            .setTitle("Power off the VM?")
            .setMessage("This is like pulling the plug. Unsaved data in the VM may be lost.")
            .setPositiveButton("Power off") { _, _ ->
                startService(Intent(this, VmService::class.java).setAction("stop"))
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun tail(f: File, n: Int = 6000): String {
        if (!f.exists()) return "(none)"
        RandomAccessFile(f, "r").use {
            val len = it.length()
            val start = maxOf(0L, len - n)
            val b = ByteArray((len - start).toInt())
            it.seek(start)
            it.readFully(b)
            return String(b)
        }
    }

    private fun logDialog() {
        val d = vmDir()
        val tv = TextView(this).apply {
            textSize = 10f
            setPadding(24, 24, 24, 24)
            setTextIsSelectable(true)
            text = "== qemu.log ==\n" + tail(File(d, "qemu.log"), 3000) +
                "\n\n== guest console (last lines) ==\n" + tail(File(d, "console.log")) +
                "\n\n== qemu debug (guest errors) ==\n" + tail(File(d, "qemu-debug.log"), 1500)
        }
        AlertDialog.Builder(this)
            .setTitle("VM log")
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Close", null)
            .show()
    }
}
