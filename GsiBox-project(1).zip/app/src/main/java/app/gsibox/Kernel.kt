package app.gsibox

import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.GZIPInputStream

/**
 * QEMU only boots a raw arm64 "Image" (has the bytes ARM\x64 at offset 56).
 * Kernels inside boot.img files are often gzip or lz4 compressed, and QEMU silently
 * hangs with a black screen if it is given those. This unpacks them.
 */
object Kernel {
    private fun isImage(b: ByteArray) =
        b.size > 64 && b[56] == 'A'.code.toByte() && b[57] == 'R'.code.toByte() &&
            b[58] == 'M'.code.toByte() && b[59] == 0x64.toByte()

    private fun isGzip(b: ByteArray) = b.size > 2 && b[0] == 0x1f.toByte() && b[1] == 0x8b.toByte()

    private fun isLz4Legacy(b: ByteArray) = b.size > 8 &&
        b[0] == 0x02.toByte() && b[1] == 0x21.toByte() && b[2] == 0x4c.toByte() && b[3] == 0x18.toByte()

    /** Returns a human readable status; rewrites [f] in place when it had to be decompressed. */
    fun normalize(f: File): String {
        var data = f.readBytes()
        var note = ""
        try {
            if (isGzip(data)) {
                data = GZIPInputStream(data.inputStream()).use { it.readBytes() }
                note = "gzip-compressed kernel unpacked. "
            } else if (isLz4Legacy(data)) {
                data = lz4Legacy(data)
                note = "lz4-compressed kernel unpacked. "
            }
        } catch (e: Exception) {
            return "WARNING: could not decompress the kernel (${e.message}). It will probably not boot."
        }
        if (isImage(data)) {
            if (note.isNotEmpty()) f.writeBytes(data)
            return note + "Kernel OK (arm64 Image, ${data.size shr 20} MB)."
        }
        return "WARNING: this is not a raw arm64 Image, so QEMU cannot boot it (black screen). " +
            "Use a kernel built for a virtual machine, e.g. the Cuttlefish / generic arm64 kernel, not your phone's own kernel."
    }

    /** One-line description of what the kernel contains, to explain a silent boot. */
    fun report(f: File): String = try {
        val b = f.readBytes()
        val s = String(b, Charsets.ISO_8859_1)
        val flags = ByteBuffer.wrap(b, 24, 8).order(ByteOrder.LITTLE_ENDIAN).long
        val page = when (((flags shr 1) and 3).toInt()) { 1 -> "4K"; 2 -> "16K"; 3 -> "64K"; else -> "?" }
        val i = s.indexOf("Linux version ")
        val ver = if (i >= 0) s.substring(i, minOf(i + 110, s.length)).substringBefore('\n') else "unknown"
        fun has(x: String) = if (s.contains(x)) "yes" else "NO"
        "$ver | page size $page | pl011 console: ${has("pl011")} | virtio_blk: ${has("virtio_blk")} | " +
            "virtio_pci: ${has("virtio_pci")} | binder: ${has("binder")}"
    } catch (t: Throwable) {
        "report failed: ${t.message}"
    }

    private fun lz4Legacy(src: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(src.size * 3)
        val dst = ByteArray(8 shl 20)
        var p = 4
        while (p + 4 <= src.size) {
            val size = (src[p].toInt() and 0xff) or ((src[p + 1].toInt() and 0xff) shl 8) or
                ((src[p + 2].toInt() and 0xff) shl 16) or ((src[p + 3].toInt() and 0xff) shl 24)
            p += 4
            if (size <= 0 || p + size > src.size) break // end of stream / appended data
            val n = lz4Block(src, p, p + size, dst)
            out.write(dst, 0, n)
            p += size
        }
        return out.toByteArray()
    }

    private fun lz4Block(src: ByteArray, start: Int, end: Int, dst: ByteArray): Int {
        var s = start
        var d = 0
        while (s < end) {
            val tok = src[s++].toInt() and 0xff
            var lit = tok ushr 4
            if (lit == 15) {
                while (true) {
                    val b = src[s++].toInt() and 0xff
                    lit += b
                    if (b != 255) break
                }
            }
            System.arraycopy(src, s, dst, d, lit)
            s += lit
            d += lit
            if (s >= end) break
            val off = (src[s].toInt() and 0xff) or ((src[s + 1].toInt() and 0xff) shl 8)
            s += 2
            var ml = tok and 15
            if (ml == 15) {
                while (true) {
                    val b = src[s++].toInt() and 0xff
                    ml += b
                    if (b != 255) break
                }
            }
            ml += 4
            var m = d - off
            repeat(ml) { dst[d++] = dst[m++] }
        }
        return d
    }
}
