package app.gsibox

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View

/** Draws the VM framebuffer letter-boxed and forwards touches as absolute pointer events. */
class VncView(ctx: Context) : View(ctx) {
    var client: VncClient? = null
    var status: String = "Starting..."

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 40f
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }
    private val dst = Rect()

    init {
        setBackgroundColor(Color.BLACK)
    }

    override fun onDraw(canvas: Canvas) {
        val c = client
        val bmp = c?.bitmap
        if (c == null || bmp == null) {
            canvas.drawText(status, width / 2f, height / 2f, textPaint)
            return
        }
        val scale = minOf(width / bmp.width.toFloat(), height / bmp.height.toFloat())
        val dw = (bmp.width * scale).toInt()
        val dh = (bmp.height * scale).toInt()
        val left = (width - dw) / 2
        val top = (height - dh) / 2
        dst.set(left, top, left + dw, top + dh)
        c.draw(canvas, dst, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val c = client ?: return true
        val bmp = c.bitmap ?: return true
        if (dst.width() <= 0 || dst.height() <= 0) return true
        val fx = ((e.x - dst.left) / dst.width() * bmp.width).toInt().coerceIn(0, bmp.width - 1)
        val fy = ((e.y - dst.top) / dst.height() * bmp.height).toInt().coerceIn(0, bmp.height - 1)
        val up = e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL
        c.pointer(if (up) 0 else 1, fx, fy)
        return true
    }
}
