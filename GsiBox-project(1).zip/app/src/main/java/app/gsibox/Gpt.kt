package app.gsibox

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID
import java.util.zip.CRC32

/** One GPT partition: [size] bytes, filled by [write] (null = zeros / sparse hole). */
class Part(val name: String, val size: Long, val write: ((RandomAccessFile, Long) -> Unit)? = null)

/** Writes a disk image with a GUID partition table, so the guest sees /dev/block/by-name/<name>. */
object Gpt {
    private const val SECTOR = 512L
    private const val ALIGN = 1L shl 20
    private val TYPE = UUID.fromString("0FC63DAF-8483-4772-8E79-3D69D8477DE4")

    private fun alignUp(v: Long, a: Long) = (v + a - 1) / a * a

    private fun guid(u: UUID): ByteArray {
        val b = ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN)
        b.putLong(u.mostSignificantBits)
        b.putLong(u.leastSignificantBits)
        val s = b.array()
        // first three fields are stored little endian
        return byteArrayOf(
            s[3], s[2], s[1], s[0], s[5], s[4], s[7], s[6],
            s[8], s[9], s[10], s[11], s[12], s[13], s[14], s[15]
        )
    }

    private fun crc(b: ByteArray): Long {
        val c = CRC32()
        c.update(b, 0, b.size)
        return c.value
    }

    private fun header(
        current: Long, backup: Long, firstUsable: Long, lastUsable: Long,
        disk: UUID, entriesLba: Long, entriesCrc: Long
    ): ByteArray {
        val h = ByteArray(92)
        val b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
        b.put("EFI PART".toByteArray(Charsets.US_ASCII))
        b.putInt(0x00010000)
        b.putInt(92)
        b.putInt(0) // header crc, filled below
        b.putInt(0)
        b.putLong(current)
        b.putLong(backup)
        b.putLong(firstUsable)
        b.putLong(lastUsable)
        b.put(guid(disk))
        b.putLong(entriesLba)
        b.putInt(128)
        b.putInt(128)
        b.putInt(entriesCrc.toInt())
        ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN).putInt(16, crc(h).toInt())
        return h
    }

    /** Returns the byte offset of each partition inside the image. */
    fun build(out: File, parts: List<Part>): List<Long> {
        require(parts.size <= 128)
        val offsets = ArrayList<Long>()
        var off = ALIGN
        for (p in parts) {
            offsets.add(off)
            off = alignUp(off + p.size, ALIGN)
        }
        val total = off + ALIGN
        val totalSectors = total / SECTOR
        val lastLba = totalSectors - 1
        val diskGuid = UUID.randomUUID()

        out.delete()
        RandomAccessFile(out, "rw").use { raf ->
            raf.setLength(total)
            parts.forEachIndexed { i, p -> p.write?.invoke(raf, offsets[i]) }

            val entries = ByteArray(128 * 128)
            parts.forEachIndexed { i, p ->
                val e = ByteBuffer.wrap(entries, i * 128, 128).order(ByteOrder.LITTLE_ENDIAN)
                e.put(guid(TYPE))
                e.put(guid(UUID.randomUUID()))
                e.putLong(offsets[i] / SECTOR)
                e.putLong((offsets[i] + p.size) / SECTOR - 1)
                e.putLong(0L)
                val nameBytes = p.name.take(36).toByteArray(Charsets.UTF_16LE)
                e.put(nameBytes)
            }
            val entCrc = crc(entries)
            val firstUsable = 34L
            val lastUsable = lastLba - 33

            // protective MBR
            val mbr = ByteArray(512)
            val mb = ByteBuffer.wrap(mbr).order(ByteOrder.LITTLE_ENDIAN)
            mb.position(446)
            mb.put(0.toByte())
            mb.put(byteArrayOf(0.toByte(), 2.toByte(), 0.toByte()))
            mb.put(0xEE.toByte())
            mb.put(byteArrayOf(0xFF.toByte(), 0xFF.toByte(), 0xFF.toByte()))
            mb.putInt(1)
            mb.putInt(minOf(totalSectors - 1, 0xFFFFFFFFL).toInt())
            mbr[510] = 0x55
            mbr[511] = 0xAA.toByte()
            raf.seek(0)
            raf.write(mbr)

            // primary header + entries
            val ph = ByteArray(512)
            System.arraycopy(header(1, lastLba, firstUsable, lastUsable, diskGuid, 2, entCrc), 0, ph, 0, 92)
            raf.seek(SECTOR)
            raf.write(ph)
            raf.seek(2 * SECTOR)
            raf.write(entries)

            // backup entries + header
            raf.seek((lastLba - 32) * SECTOR)
            raf.write(entries)
            val bh = ByteArray(512)
            System.arraycopy(header(lastLba, 1, firstUsable, lastUsable, diskGuid, lastLba - 32, entCrc), 0, bh, 0, 92)
            raf.seek(lastLba * SECTOR)
            raf.write(bh)
        }
        return offsets
    }
}
