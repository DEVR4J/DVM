package app.gsibox

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.tukaani.xz.XZInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.util.zip.GZIPInputStream
import java.util.zip.ZipInputStream

/** Copies a picked file into the app's private storage, unpacking zip/xz/gz and un-sparsing images. */
object Importer {
    fun displayName(ctx: Context, uri: Uri): String {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0) ?: "file"
        }
        return uri.lastPathSegment ?: "file"
    }

    private fun matches(kind: String, n: String): Boolean = when (kind) {
        "system" -> n == "system.img" || n == "system.img.xz" || n == "system.img.gz" ||
            ((n.contains("system") || n.contains("gsi")) && n.contains(".img"))
        "vendor" -> n.startsWith("vendor") && !n.startsWith("vendor_boot") && n.contains(".img")
        "boot" -> n.startsWith("boot") && n.contains(".img")
        else -> false
    }

    fun importFile(ctx: Context, uri: Uri, kind: String, progress: (String) -> Unit): File {
        val dir = ctx.vmDir()
        val name = displayName(ctx, uri).lowercase()
        val dest = File(dir, "$kind.img")
        val tmp = File(dir, "$kind.tmp")
        val isImageKind = kind == "system" || kind == "vendor"

        if (name.endsWith(".zip") && !isImageKind && kind != "boot") {
            error("Select the extracted $kind file, not a zip.")
        }

        val raw = ctx.contentResolver.openInputStream(uri) ?: error("Cannot open the selected file.")
        raw.use { base ->
            var stream: InputStream = base
            var effective = name
            if (name.endsWith(".zip")) {
                val zin = ZipInputStream(BufferedInputStream(base, 1 shl 20))
                var found = false
                while (true) {
                    val e = zin.nextEntry ?: break
                    val n = e.name.substringAfterLast('/').lowercase()
                    if (!e.isDirectory && matches(kind, n)) {
                        effective = n
                        found = true
                        break
                    }
                }
                if (!found) error("No $kind image found inside the zip.")
                stream = zin
            }
            if (effective.endsWith(".xz")) stream = XZInputStream(stream)
            else if (effective.endsWith(".gz") && kind != "kernel") stream = GZIPInputStream(stream, 1 shl 16)
            copy(stream, tmp, progress)
        }

        if (kind == "boot") {
            if (!BootImg.isBootImg(tmp)) {
                tmp.delete()
                error("That is not an Android boot.img.")
            }
            progress("Extracting kernel and ramdisk...")
            val r = BootImg.extract(tmp, File(dir, "kernel.img"), File(dir, "ramdisk.img"))
            tmp.delete()
            progress("kernel ${r.kernelSize shr 20} MB, ramdisk ${r.ramdiskSize shr 20} MB (boot header v${r.version})")
            return File(dir, "kernel.img")
        }

        if (isImageKind && Sparse.isSparse(tmp)) {
            progress("Converting sparse image to raw...")
            Sparse.unsparse(tmp, dest)
            tmp.delete()
        } else {
            dest.delete()
            if (!tmp.renameTo(dest)) error("Could not move imported file into place.")
        }
        return dest
    }

    private fun copy(inp: InputStream, out: File, progress: (String) -> Unit) {
        out.outputStream().buffered(1 shl 20).use { o ->
            val buf = ByteArray(1 shl 20)
            var total = 0L
            var next = 0L
            while (true) {
                val n = inp.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
                total += n
                if (total >= next) {
                    progress("copied ${total shr 20} MB...")
                    next = total + (32L shl 20)
                }
            }
        }
    }
}
