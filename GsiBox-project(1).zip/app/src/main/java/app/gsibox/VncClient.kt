package app.gsibox

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

/** Minimal RFB (VNC) client: no auth, Raw encoding + DesktopSize, talks to QEMU on 127.0.0.1:5900. */
class VncClient(
    private val onChange: () -> Unit,
    private val onStatus: (String) -> Unit
) {
    private val lock = Any()
    private val exec = Executors.newSingleThreadExecutor()

    @Volatile
    var bitmap: Bitmap? = null
        private set

    @Volatile
    private var running = false
    private var sock: Socket? = null

    @Volatile
    private var out: DataOutputStream? = null
    private var fbW = 0
    private var fbH = 0

    fun start() {
        running = true
        Thread { loop() }.start()
    }

    fun stop() {
        running = false
        try {
            sock?.close()
        } catch (e: Exception) {
        }
        exec.shutdown()
    }

    fun draw(c: Canvas, dst: Rect, p: Paint) {
        synchronized(lock) { bitmap?.let { c.drawBitmap(it, null, dst, p) } }
    }

    private fun loop() {
        while (running) {
            try {
                session()
            } catch (e: Exception) {
                if (running) onStatus("Waiting for the VM display...")
            }
            out = null
            if (running) Thread.sleep(2000)
        }
    }

    private fun DataInputStream.skipFully(n: Int) {
        var left = n
        val tmp = ByteArray(4096)
        while (left > 0) {
            val r = read(tmp, 0, minOf(left, tmp.size))
            if (r < 0) throw EOFException()
            left -= r
        }
    }

    private fun resize(w: Int, h: Int) {
        synchronized(lock) {
            fbW = w
            fbH = h
            bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        }
    }

    private fun request(incremental: Boolean) {
        val o = out ?: return
        synchronized(o) {
            o.writeByte(3)
            o.writeByte(if (incremental) 1 else 0)
            o.writeShort(0)
            o.writeShort(0)
            o.writeShort(fbW)
            o.writeShort(fbH)
            o.flush()
        }
    }

    private fun session() {
        val s = Socket()
        s.connect(InetSocketAddress("127.0.0.1", 5900), 2000)
        s.tcpNoDelay = true
        sock = s
        val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 1 shl 16))
        val o = DataOutputStream(BufferedOutputStream(s.getOutputStream()))

        inp.skipFully(12) // server version
        o.write("RFB 003.008\n".toByteArray())
        o.flush()
        val n = inp.readUnsignedByte()
        if (n == 0) throw IOException("server refused connection")
        val types = ByteArray(n)
        inp.readFully(types)
        if (!types.contains(1.toByte())) throw IOException("VNC wants authentication")
        o.writeByte(1)
        o.flush()
        if (inp.readInt() != 0) throw IOException("security handshake failed")
        o.writeByte(1) // ClientInit: shared
        o.flush()

        val w = inp.readUnsignedShort()
        val h = inp.readUnsignedShort()
        inp.skipFully(16) // server pixel format
        inp.skipFully(inp.readInt()) // desktop name

        // SetPixelFormat: 32bpp little-endian, R<<16 | G<<8 | B
        o.writeByte(0)
        o.write(ByteArray(3))
        o.writeByte(32)
        o.writeByte(24)
        o.writeByte(0)
        o.writeByte(1)
        o.writeShort(255)
        o.writeShort(255)
        o.writeShort(255)
        o.writeByte(16)
        o.writeByte(8)
        o.writeByte(0)
        o.write(ByteArray(3))
        // SetEncodings: Raw, DesktopSize
        o.writeByte(2)
        o.writeByte(0)
        o.writeShort(2)
        o.writeInt(0)
        o.writeInt(-223)
        o.flush()

        resize(w, h)
        out = o
        request(false)
        onStatus("")

        while (running) {
            when (inp.readUnsignedByte()) {
                0 -> {
                    inp.readByte()
                    val rects = inp.readUnsignedShort()
                    repeat(rects) {
                        val x = inp.readUnsignedShort()
                        val y = inp.readUnsignedShort()
                        val rw = inp.readUnsignedShort()
                        val rh = inp.readUnsignedShort()
                        when (val enc = inp.readInt()) {
                            0 -> readRaw(inp, x, y, rw, rh)
                            -223 -> resize(rw, rh)
                            else -> throw IOException("unsupported encoding $enc")
                        }
                    }
                    onChange()
                    request(true)
                }
                1 -> {
                    inp.readByte()
                    inp.readUnsignedShort()
                    val c = inp.readUnsignedShort()
                    inp.skipFully(c * 6)
                }
                2 -> {}
                3 -> {
                    inp.skipFully(3)
                    inp.skipFully(inp.readInt())
                }
                else -> throw IOException("unknown server message")
            }
        }
    }

    private fun readRaw(inp: DataInputStream, x: Int, y: Int, rw: Int, rh: Int) {
        val bytes = ByteArray(rw * rh * 4)
        inp.readFully(bytes)
        val px = IntArray(rw * rh)
        var j = 0
        for (i in px.indices) {
            px[i] = (0xFF shl 24) or
                ((bytes[j + 2].toInt() and 0xFF) shl 16) or
                ((bytes[j + 1].toInt() and 0xFF) shl 8) or
                (bytes[j].toInt() and 0xFF)
            j += 4
        }
        synchronized(lock) {
            bitmap?.let {
                if (x + rw <= it.width && y + rh <= it.height) it.setPixels(px, 0, rw, x, y, rw, rh)
            }
        }
    }

    // ---- input (sent on a worker thread; sockets can't be used on the UI thread) ----

    private fun send(f: (DataOutputStream) -> Unit) {
        val o = out ?: return
        try {
            exec.execute {
                try {
                    synchronized(o) {
                        f(o)
                        o.flush()
                    }
                } catch (e: Exception) {
                }
            }
        } catch (e: Exception) {
        }
    }

    fun pointer(mask: Int, x: Int, y: Int) = send {
        it.writeByte(5)
        it.writeByte(mask)
        it.writeShort(x)
        it.writeShort(y)
    }

    fun key(down: Boolean, sym: Int) = send {
        it.writeByte(4)
        it.writeByte(if (down) 1 else 0)
        it.writeShort(0)
        it.writeInt(sym)
    }

    fun combo(vararg syms: Int) {
        for (s in syms) key(true, s)
        for (s in syms.reversed()) key(false, s)
    }

    fun typeText(t: String) {
        for (ch in t) {
            val sym = when {
                ch == '\n' -> 0xff0d
                ch.code < 0x100 -> ch.code
                else -> 0x01000000 + ch.code
            }
            key(true, sym)
            key(false, sym)
        }
    }
}
