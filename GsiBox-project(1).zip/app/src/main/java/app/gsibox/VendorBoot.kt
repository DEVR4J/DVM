package app.gsibox

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Reads a vendor_boot image (header v3/v4): the vendor ramdisk, its kernel command line and bootconfig. */
object VendorBoot {
    class Result(val ramdiskSize: Long, val cmdline: String, val bootconfig: String)

    private fun align(v: Long, a: Long) = (v + a - 1) / a * a

    private fun cstr(b: ByteArray, off: Int, len: Int): String {
        var end = off
        while (end < off + len && b[end].toInt() != 0) end++
        return String(b, off, end - off, Charsets.ISO_8859_1)
    }

    fun extract(src: File, ramdiskOut: File): Result {
        RandomAccessFile(src, "r").use { raf ->
            val h = ByteArray(2128)
            raf.readFully(h)
            if (String(h, 0, 8, Charsets.ISO_8859_1) != "VNDRBOOT") error("vendor_boot.img is not a vendor boot image.")
            val b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
            val ver = b.getInt(8)
            if (ver < 3) error("vendor_boot header v$ver is not supported.")
            val page = b.getInt(12).toLong() and 0xffffffffL
            val rdSize = b.getInt(24).toLong() and 0xffffffffL
            val cmd = cstr(h, 28, 2048)
            val hdrSize = b.getInt(2096).toLong() and 0xffffffffL
            val dtbSize = b.getInt(2100).toLong() and 0xffffffffL
            var tableSize = 0L
            var bcSize = 0L
            if (ver >= 4) {
                tableSize = b.getInt(2112).toLong() and 0xffffffffL
                bcSize = b.getInt(2124).toLong() and 0xffffffffL
            }
            val rdOff = align(hdrSize, page)
            val dtbOff = rdOff + align(rdSize, page)
            val tableOff = dtbOff + align(dtbSize, page)
            val bcOff = tableOff + align(tableSize, page)

            raf.seek(rdOff)
            ramdiskOut.outputStream().buffered(1 shl 20).use { o ->
                val buf = ByteArray(1 shl 20)
                var left = rdSize
                while (left > 0) {
                    val n = raf.read(buf, 0, minOf(left, buf.size.toLong()).toInt())
                    if (n < 0) error("vendor_boot.img is truncated.")
                    o.write(buf, 0, n)
                    left -= n
                }
            }
            var bc = ""
            if (bcSize > 0) {
                val bb = ByteArray(bcSize.toInt())
                raf.seek(bcOff)
                raf.readFully(bb)
                bc = String(bb, Charsets.ISO_8859_1).substringBefore('\u0000')
            }
            return Result(rdSize, cmd, bc)
        }
    }
}
