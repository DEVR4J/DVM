package app.gsibox

import android.content.Context
import java.io.File

fun Context.vmDir(): File = File(filesDir, "vm").apply { mkdirs() }

class VmConfig(ctx: Context) {
    private val sp = ctx.getSharedPreferences("vm", Context.MODE_PRIVATE)

    var ramMb: Int
        get() = sp.getInt("ram", 3072)
        set(v) { sp.edit().putInt("ram", v).apply() }

    var cpus: Int
        get() = sp.getInt("cpus", 4)
        set(v) { sp.edit().putInt("cpus", v).apply() }

    var dataGb: Int
        get() = sp.getInt("dataGb", 16)
        set(v) { sp.edit().putInt("dataGb", v).apply() }

    var width: Int
        get() = sp.getInt("w", 720)
        set(v) { sp.edit().putInt("w", v).apply() }

    var height: Int
        get() = sp.getInt("h", 1280)
        set(v) { sp.edit().putInt("h", v).apply() }

    var dpi: Int
        get() = sp.getInt("dpi", 280)
        set(v) { sp.edit().putInt("dpi", v).apply() }

    var cmdline: String
        get() = sp.getString("cmdline", DEFAULT_CMDLINE) ?: DEFAULT_CMDLINE
        set(v) { sp.edit().putString("cmdline", v).apply() }

    var extraArgs: String
        get() = sp.getString("extra", "") ?: ""
        set(v) { sp.edit().putString("extra", v).apply() }

    companion object {
        const val DEFAULT_CMDLINE =
            "console=ttyAMA0 earlycon=pl011,mmio32,0x9000000 androidboot.hardware=ranchu"
    }
}
