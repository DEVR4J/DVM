# GsiBox

Android app that boots an Android GSI as a virtual phone inside the app (QEMU, arm64, software emulation).

## Build on GitHub
1. Create a new **public** repo and upload the contents of this folder (not the zip itself).
   If the web uploader skips the hidden `.github` folder, create the file
   `.github/workflows/build.yml` with "Add file > Create new file" and paste the yml.
2. Open the **Actions** tab, run **Build GsiBox APK** (it also runs on every push).
3. First run builds QEMU (about 10-25 min, cached afterwards). Download `GsiBox-debug-apk` from the run page and install it.

## Quick use
Pick the GSI, then either **boot.img** (kernel and ramdisk are extracted automatically, header v0-v4, gzip or raw kernel)
or a kernel and ramdisk separately, optionally the vendor image, choose a display preset and storage size, tap Start.
The Back button leaves the VM running in the background; reopen it with "Open running VM".
If the device exposes /dev/kvm to apps the VM uses it automatically, otherwise it falls back to software emulation.

## What you need on the phone
A GSI alone cannot boot. QEMU needs a kernel, and usually a ramdisk and vendor image:

| Item | Required | Notes |
|---|---|---|
| GSI (`.img`, `.zip`, `.xz`, `.gz`) | yes | arm64, sparse images are converted automatically |
| Kernel (arm64 `Image`) | yes | must have virtio drivers and Android features (binder etc.) |
| Ramdisk | usually | first-stage init that mounts the disks |
| Vendor image | usually | provides fstab / HALs for the virtual device |

Cuttlefish (`aosp_cf_arm64`) kernel, ramdisk and vendor images are the most likely to work with a standard GSI.
Disks are exposed to the guest as virtio-blk: system = vda, vendor = vdb (if set), userdata = next.
Edit the kernel command line or add extra QEMU arguments in the app to match your kernel.

## Notes
- No KVM is available to apps, so everything is emulated: expect slow boot (several minutes) and a laggy UI.
- Display: VNC over localhost. One finger only. Back / Home / Recents buttons send Meta+Esc, Meta+Enter, Alt+Tab.
- The guest is a clean VM. Nothing is rooted or injected by this app. Use a *user* build GSI if you want no `su` at all.
- Use "Log" in the VM screen to see QEMU output and the guest serial console.
