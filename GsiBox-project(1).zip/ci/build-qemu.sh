#!/bin/sh
# Builds a fully static qemu-system-aarch64 (musl) inside an arm64 Alpine container.
# The result is copied to /w/qemu-out/libqemu.so (named .so so Android installs it
# into nativeLibraryDir, the only place an app may exec binaries from).
set -eux

QEMU_VERSION=9.1.2

apk add --no-cache \
    build-base linux-headers python3 py3-pip py3-setuptools meson ninja pkgconf \
    flex bison perl bash curl xz tar \
    glib-dev glib-static pixman-dev pixman-static zlib-dev zlib-static \
    pcre2-dev libffi-dev util-linux-dev util-linux-static \
    gettext-dev gettext-static

# Alpine ships libfdt only as a shared lib; build a static libfdt.a from the dtc sources.
cd /tmp
curl -fsSL -o dtc.tar.gz https://git.kernel.org/pub/scm/utils/dtc/dtc.git/snapshot/dtc-1.7.0.tar.gz \
  || curl -fsSL -o dtc.tar.gz https://github.com/dgibson/dtc/archive/refs/tags/v1.7.0.tar.gz
mkdir dtc-src
tar xf dtc.tar.gz -C dtc-src --strip-components=1
cd dtc-src
make libfdt/libfdt.a
cp libfdt/libfdt.a /usr/lib/
cp libfdt/libfdt.h libfdt/fdt.h libfdt/libfdt_env.h /usr/include/
ls -l /usr/lib/libfdt*

# Static libslirp (user-mode networking). If this fails, build QEMU without networking.
cd /tmp
SLIRP_OPT=--disable-slirp
if curl -fsSL -o slirp.tar.gz https://gitlab.freedesktop.org/slirp/libslirp/-/archive/v4.8.0/libslirp-v4.8.0.tar.gz \
   && mkdir slirp-src && tar xf slirp.tar.gz -C slirp-src --strip-components=1 \
   && meson setup slirp-src/build slirp-src --prefix=/usr --libdir=lib --default-library=static \
   && ninja -C slirp-src/build install; then
  SLIRP_OPT=--enable-slirp
fi
echo "SLIRP_OPT=$SLIRP_OPT"

cd /tmp
curl -fsSL -o qemu.tar.xz "https://download.qemu.org/qemu-${QEMU_VERSION}.tar.xz"
tar xf qemu.tar.xz
cd "qemu-${QEMU_VERSION}"

./configure \
    --static \
    --target-list=aarch64-softmmu \
    --disable-docs --disable-tools --disable-guest-agent --disable-user \
    --disable-werror \
    --disable-gtk --disable-sdl --disable-opengl \
    --disable-bzip2 --disable-lzo --disable-snappy --disable-zstd --disable-curl \
    --disable-libssh --disable-gnutls --disable-nettle --disable-gcrypt --disable-vde \
    --disable-brlapi --disable-libusb --disable-libnfs --disable-rbd --disable-fuse \
    --disable-seccomp --disable-numa --disable-libiscsi --disable-smartcard \
    --disable-usb-redir --disable-vnc-sasl --disable-png --disable-glusterfs \
    --enable-fdt=system \
    --disable-curses $SLIRP_OPT

cd build
ninja -j"$(nproc)" qemu-system-aarch64
cd ..

strip build/qemu-system-aarch64
./build/qemu-system-aarch64 --version
./build/qemu-system-aarch64 -netdev help | head -n 20 || true

mkdir -p /w/qemu-out
cp build/qemu-system-aarch64 /w/qemu-out/libqemu.so
ls -l /w/qemu-out
